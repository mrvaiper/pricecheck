<?php
// config/db.php
$host = 'localhost';
$db   = 'rrrprice';
$user = 'rrrprice';
$pass = 'Kzz3w77yhRJ4iCFd';
$dsn  = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}